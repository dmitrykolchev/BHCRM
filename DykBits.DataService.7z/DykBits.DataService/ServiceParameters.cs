﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DykBits.DataService
{
    class ServiceParameters
    {
        public const string ServiceNamespace = "http://www.dykbits.net/2014/crm/documentservice";
    }
}
